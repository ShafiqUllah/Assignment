package practice7.prob1;

public abstract class Role {
	abstract double getSalary();
	abstract double getUnits();

}
