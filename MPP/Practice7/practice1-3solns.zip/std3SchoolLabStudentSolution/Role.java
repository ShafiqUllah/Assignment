package std3SchoolLabStudentSolution;

public abstract class Role {
	abstract double getSalary();
	abstract double getUnits();

}
