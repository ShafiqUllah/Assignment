package std2;

public class SalesDept extends Department{
	//implement
	
	
	public void requestMarketingMaterials() {
		//not implemented
	}
	
	@Override
	public String getName() {
		return "Sales";
	}
}
