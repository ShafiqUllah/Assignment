package std2;

public class MarketingDept extends Department{
	//implement
	
	public void applyForJob() {
		//not implemented
	}
	
	@Override
	public String getName() {
		return "Marketing";
	}
}
