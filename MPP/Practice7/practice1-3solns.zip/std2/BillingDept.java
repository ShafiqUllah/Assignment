package std2;

public class BillingDept extends Department{
	//implement
	
	public String monthlyReport() {
		//not implemented
		return null;
	}

	@Override
	public String getName() {
		return "Billing";
	}
}
