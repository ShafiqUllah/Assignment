package fetenaFactory;

public class Checking extends Account{
	
	 Checking(String accountNum, double balance, double rate) {
		super(accountNum, balance, rate);
	}
	

}
