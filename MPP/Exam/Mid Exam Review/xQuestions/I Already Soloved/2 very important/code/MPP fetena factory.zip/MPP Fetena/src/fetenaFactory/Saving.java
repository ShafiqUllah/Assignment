package fetenaFactory;

public class Saving extends Account {

	Saving(String accountNum, double balance, double rate) {
		super(accountNum, balance, rate);

	}

}
