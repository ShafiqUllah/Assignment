package lab4.practice2;

public class SalesDept extends Department{
	//implement
	
	
	public SalesDept( ) {
		super();
		// TODO Auto-generated constructor stub
	}

	public void requestMarketingMaterials() {
		//not implemented
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Sales";
	}
}
