package lab4.practice2;

public class MarketingDept extends Department{
	//implement
	
	public MarketingDept( ) {
		super();
		// TODO Auto-generated constructor stub
	}

	public void applyForJob() {
		//not implemented
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Marketing";
	}
}
