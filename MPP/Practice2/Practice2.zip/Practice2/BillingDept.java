package lab4.practice2;

public class BillingDept extends Department{
	//implement
	
	public BillingDept() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public String monthlyReport() {
		//not implemented
		return null;
	}

	

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Billing";
	}
}
