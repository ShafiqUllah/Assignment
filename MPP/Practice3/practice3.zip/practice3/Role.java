package practice3;

public abstract class Role {
	public abstract double getSalary();
	public abstract double getUnits(); 

}
