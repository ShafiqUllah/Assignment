package lab5.prob1;

public class FlyWithWings implements FlyBehavior{


	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("\tflying with wings");
		
	}

}
