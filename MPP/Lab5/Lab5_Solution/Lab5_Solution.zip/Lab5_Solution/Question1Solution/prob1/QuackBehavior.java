package lab5.prob1;

public interface QuackBehavior {

	public void quack();
}
