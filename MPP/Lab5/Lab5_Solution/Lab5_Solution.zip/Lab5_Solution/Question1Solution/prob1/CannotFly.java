package lab5.prob1;

public class CannotFly implements FlyBehavior{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("\tcannot fly");
	}

}
