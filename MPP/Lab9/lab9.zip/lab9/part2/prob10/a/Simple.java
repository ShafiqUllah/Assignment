package lab9.part2.prob10.a;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
