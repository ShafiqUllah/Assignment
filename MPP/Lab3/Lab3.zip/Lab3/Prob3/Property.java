package lab3.prob3;

public abstract class Property {
	public abstract Address getAddress();
	public abstract double computeRent();
}
